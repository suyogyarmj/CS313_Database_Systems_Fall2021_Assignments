-- Order with the maximum order ID

DECLARE @maxid AS INT = (SELECT MAX(OrderId)
                         FROM Sales.[Order]);

SELECT OrderId, OrderDate, EmployeeId, CustomerId
FROM Sales.[Order]
WHERE orderid = @maxid;
GO

SELECT orderid, orderdate, EmployeeId, CustomerId
FROM Sales.[Order]
WHERE orderid = (SELECT MAX(O.orderid)
                 FROM Sales.[Order] AS O);


-- Scalar subquery expected to return one value
SELECT orderid
FROM Sales.[Order]
WHERE EmployeeId = 
  (SELECT E.EmployeeId
   FROM HumanResources.Employee AS E
   WHERE E.EmployeeLastName LIKE N'C%');
GO

SELECT orderid
FROM Sales.[Order]
WHERE EmployeeId = 
  (SELECT E.EmployeeId
   FROM HumanResources.Employee AS E
   WHERE E.EmployeeLastName LIKE N'D%');
GO

SELECT orderid
FROM Sales.[Order]
WHERE EmployeeId = 
  (SELECT E.EmployeeId
   FROM HumanResources.Employee AS E
   WHERE E.EmployeeLastName LIKE N'A%');

---------------------------------------------------------------------
-- Multi-Valued Subqueries
---------------------------------------------------------------------

SELECT orderid
FROM Sales.[Order]
WHERE EmployeeId IN
  (SELECT E.EmployeeId
   FROM HumanResources.Employee AS E
   WHERE E.EmployeeLastName LIKE N'D%');

SELECT O.orderid
FROM HumanResources.Employee AS E
  INNER JOIN Sales.[Order] AS O
    ON E.EmployeeId = O.EmployeeId
WHERE E.EmployeeLastName LIKE N'D%';

-- Orders placed by US customers
SELECT CustomerId, orderid, orderdate, EmployeeId
FROM Sales.[Order]
WHERE CustomerId IN
  (SELECT C.CustomerID
   FROM Data.Customer AS C
   WHERE C.CountryId = N'USA');

-- Customers who placed no orders
SELECT CustomerID, CustomerName
FROM Data.Customer
WHERE CustomerID NOT IN
  (SELECT O.CustomerId
   FROM Sales.[Order] AS O);

-- Missing order IDs

DROP TABLE IF EXISTS dbo.Orders;
CREATE TABLE dbo.Orders(orderid INT NOT NULL CONSTRAINT PK_Orders PRIMARY KEY);

INSERT INTO dbo.Orders(orderid)
  SELECT orderid
  FROM Sales.[Order]
  WHERE orderid % 2 = 0;

SELECT n
FROM dbo.Nums
WHERE n BETWEEN (SELECT MIN(O.orderid) FROM dbo.Orders AS O)
            AND (SELECT MAX(O.orderid) FROM dbo.Orders AS O)
  AND n NOT IN (SELECT O.orderid FROM dbo.Orders AS O);

-- CLeanup
DROP TABLE IF EXISTS dbo.Orders;

---------------------------------------------------------------------
-- Correlated Subqueries
---------------------------------------------------------------------

-- Orders with maximum order ID for each customer
-- Listing 4-1: Correlated Subquery

SELECT CustomerId, orderid, orderdate, EmployeeId
FROM Sales.[Order] AS O1
WHERE orderid =
  (SELECT MAX(O2.orderid)
   FROM Sales.[Order] AS O2
   WHERE O2.CustomerId = O1.CustomerId);

SELECT MAX(O2.orderid)
FROM Sales.[Order] AS O2
WHERE O2.CustomerId = 85;

-- Percentage of customer total
SELECT orderid, productid, oldval,
  CAST(100. * oldval / (SELECT SUM(O2.oldval)
                     FROM Sales.OrderDetailsAudit AS O2
                     WHERE O2.productid = O1.productid)
       AS NUMERIC(5,2)) AS pct
FROM Sales.OrderDetailsAudit AS O1
ORDER BY productid, orderid;

-- Customers from Spain who placed orders
SELECT CustomerId, CustomerCompanyName
FROM Sales.Customer AS C
WHERE CustomerCountry = N'Spain'
  AND EXISTS
    (SELECT * FROM Sales.[Order] AS O
     WHERE O.CustomerId = C.CustomerId);

-- Customers from Spain who didn't place Orders
SELECT CustomerId, CustomerCompanyName
FROM Sales.Customer AS C
WHERE CustomerCountry  = N'Spain'
  AND NOT EXISTS
    (SELECT * FROM Sales.[Order] AS O
     WHERE O.CustomerId = C.CustomerId);

---------------------------------------------------------------------
-- Returning "Previous" or "Next" Value
---------------------------------------------------------------------
SELECT OrderId, orderdate, EmployeeId, CustomerId,
  (SELECT MAX(O2.orderid)
   FROM Sales.[Order] AS O2
   WHERE O2.orderid < O1.orderid) AS prevorderid
FROM Sales.[Order] AS O1;

SELECT orderid, orderdate, EmployeeId, CustomerId,
  (SELECT MIN(O2.orderid)
   FROM Sales.[Order] AS O2
   WHERE O2.orderid > O1.orderid) AS nextorderid
FROM Sales.[Order] AS O1;

---------------------------------------------------------------------
-- Running Aggregates
---------------------------------------------------------------------

SELECT OrderDate, Freight
FROM Sales.[Order];

SELECT OrderDate, Freight,
  (SELECT SUM(O2.Freight)
   FROM Sales.[Order] AS O2
   WHERE O2.OrderDate <= O1.OrderDate) AS runqty
FROM Sales.[Order] AS O1
ORDER BY OrderDate;

---------------------------------------------------------------------
-- Misbehaving Subqueries
---------------------------------------------------------------------

---------------------------------------------------------------------
-- NULL Trouble
---------------------------------------------------------------------

-- Customers who didn't place orders

-- Using NOT IN
SELECT CustomerId, ShipToName
FROM Sales.[Order]
WHERE CustomerId NOT IN(SELECT O.CustomerId
                    FROM Sales.[Order] AS O);

-- Add a row to the Orders table with a NULL custid
INSERT INTO Sales.[Order]
  (CustomerId, EmployeeId, orderdate, requireddate, ShipToDate, shipperid,
   freight, ShipToName, ShipToAddress, ShipToCity, ShipToRegion,
   ShipToPostalCode, ShipToCountry)
  VALUES(NULL, 1, '20160212', '20160212',
         '20160212', 1, 123.00, N'abc', N'abc', N'abc',
         N'abc', N'abc', N'abc');

-- Following returns an empty set
SELECT CustomerId, ShipToName
FROM Sales.[Order]
WHERE CustomerId NOT IN(SELECT O.CustomerId
                    FROM Sales.[Order] AS O);

-- Exclude NULLs explicitly
SELECT CustomerId, ShipToName
FROM Sales.[Order]
WHERE CustomerId NOT IN(SELECT O.CustomerId 
                    FROM Sales.[Order] AS O
                    WHERE O.CustomerId IS NOT NULL);

-- Using NOT EXISTS
SELECT CustomerId, ShipToName
FROM Sales.[Order] AS C
WHERE NOT EXISTS
  (SELECT * 
   FROM Sales.[Order] AS O
   WHERE O.CustomerId = C.CustomerId);

-- Cleanup
DELETE FROM Sales.[Order] WHERE CustomerId IS NULL;
GO

---------------------------------------------------------------------
-- Substitution Error in a Subquery Column Name
---------------------------------------------------------------------

-- Create and populate table Sales.MyShippers
DROP TABLE IF EXISTS Sales.MyShippers;

CREATE TABLE Sales.MyShippers
(
  shipper_id  INT          NOT NULL,
  companyname NVARCHAR(40) NOT NULL,
  phone       NVARCHAR(24) NOT NULL,
  CONSTRAINT PK_MyShippers PRIMARY KEY(shipper_id)
);

INSERT INTO Sales.MyShippers(shipper_id, companyname, phone)
  VALUES(1, N'Shipper GVSUA', N'(503) 555-0137'),
	      (2, N'Shipper ETYNR', N'(425) 555-0136'),
				(3, N'Shipper ZHISN', N'(415) 555-0138');
GO

-- Shippers who shipped orders to customer 43

-- Bug
SELECT shipper_id, companyname
FROM Sales.MyShippers
WHERE shipper_id IN
  (SELECT shipper_id
   FROM Sales.[Order]
   WHERE CustomerId = 43);
GO

-- The safe way using aliases, bug identified
SELECT shipper_id, companyname
FROM Sales.MyShippers
WHERE shipper_id IN
  (SELECT O.ShipperId
   FROM Sales.[Order] AS O
   WHERE O.CustomerId = 43);
GO

-- Bug corrected
SELECT shipper_id, companyname
FROM Sales.MyShippers
WHERE shipper_id IN
  (SELECT O.ShipperId
   FROM Sales.[Order] AS O
   WHERE O.CustomerId = 43);

-- Cleanup
DROP TABLE IF EXISTS Sales.MyShippers;
