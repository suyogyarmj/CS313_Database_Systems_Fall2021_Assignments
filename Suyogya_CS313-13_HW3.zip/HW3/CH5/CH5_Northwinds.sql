---------------------------------------------------------------------
-- Microsoft SQL Server T-SQL Fundamentals
-- Chapter 05 - Table Expressions
-- © Itzik Ben-Gan 
---------------------------------------------------------------------

---------------------------------------------------------------------
-- Derived Tables
---------------------------------------------------------------------

--USE TSQLV4;

SELECT *
FROM (SELECT CustomerId, CustomerCountry
      FROM Sales.Customer
      WHERE CustomerCountry = N'USA') AS USACusts;

---------------------------------------------------------------------
-- Assigning Column Aliases
---------------------------------------------------------------------

-- Following fails
/*
SELECT
  YEAR(orderdate) AS orderyear,
  COUNT(DISTINCT custid) AS numcusts
FROM Sales.Orders
GROUP BY orderyear;
*/
GO

-- Listing 5-1 Query with a Derived Table using Inline Aliasing Form
SELECT orderyear, COUNT(DISTINCT CustomerId) AS numcusts
FROM (SELECT YEAR(orderdate) AS orderyear, CustomerId
      FROM Sales.[Order]) AS D
GROUP BY orderyear;

SELECT YEAR(orderdate) AS orderyear, COUNT(DISTINCT CustomerId) AS numcusts
FROM Sales.[Order]
GROUP BY YEAR(orderdate);

-- External column aliasing
SELECT orderyear, COUNT(DISTINCT custid) AS numcusts
FROM (SELECT YEAR(orderdate), CustomerId
      FROM Sales.[Order]) AS D(orderyear, custid)
GROUP BY orderyear;
GO

---------------------------------------------------------------------
-- Using Arguments
---------------------------------------------------------------------

-- Yearly Count of Customers handled by Employee 3
DECLARE @empid AS INT = 3;

SELECT orderyear, COUNT(DISTINCT CustomerId) AS numcusts
FROM (SELECT YEAR(orderdate) AS orderyear, CustomerId
      FROM Sales.[Order]
      WHERE EmployeeId = @empid) AS D
GROUP BY orderyear;
GO

---------------------------------------------------------------------
-- Nesting
---------------------------------------------------------------------

-- Listing 5-2 Query with Nested Derived Tables
SELECT orderyear, numcusts
FROM (SELECT orderyear, COUNT(DISTINCT CustomerId) AS numcusts
      FROM (SELECT YEAR(orderdate) AS orderyear, CustomerId
            FROM Sales.[Order]) AS D1
      GROUP BY orderyear) AS D2
WHERE numcusts > 70;

SELECT YEAR(orderdate) AS orderyear, COUNT(DISTINCT CustomerId) AS numcusts
FROM Sales.[Order]
GROUP BY YEAR(orderdate)
HAVING COUNT(DISTINCT CustomerId) > 70;

---------------------------------------------------------------------
-- Multiple References
---------------------------------------------------------------------

-- Listing 5-3 Multiple Derived Tables Based on the Same Query
SELECT Cur.orderyear, 
  Cur.numcusts AS curnumcusts, Prv.numcusts AS prvnumcusts,
  Cur.numcusts - Prv.numcusts AS growth
FROM (SELECT YEAR(orderdate) AS orderyear,
        COUNT(DISTINCT CustomerId) AS numcusts
      FROM Sales.[Order]
      GROUP BY YEAR(orderdate)) AS Cur
  LEFT OUTER JOIN
     (SELECT YEAR(orderdate) AS orderyear,
        COUNT(DISTINCT CustomerId) AS numcusts
      FROM Sales.[Order]
      GROUP BY YEAR(orderdate)) AS Prv
    ON Cur.orderyear = Prv.orderyear + 1;

---------------------------------------------------------------------
-- Common Table Expressions
---------------------------------------------------------------------

WITH USACusts AS
(
  SELECT CustomerId, ShipToName
  FROM Sales.[Order]
  WHERE ShipToCountry = N'USA'
)
SELECT * FROM USACusts;

---------------------------------------------------------------------
-- Assigning Column Aliases
---------------------------------------------------------------------

-- Inline column aliasing
WITH C AS
(
  SELECT YEAR(orderdate) AS orderyear, CustomerId
  FROM Sales.[Order]
)
SELECT orderyear, COUNT(DISTINCT CustomerId) AS numcusts
FROM C
GROUP BY orderyear;

-- External column aliasing
WITH C(orderyear, custid) AS
(
  SELECT YEAR(orderdate), CustomerId
  FROM Sales.[Order]
)
SELECT orderyear, COUNT(DISTINCT custid) AS numcusts
FROM C
GROUP BY orderyear;
GO

---------------------------------------------------------------------
-- Using Arguments
---------------------------------------------------------------------

DECLARE @empid AS INT = 3;

WITH C AS
(
  SELECT YEAR(orderdate) AS orderyear, CustomerId
  FROM Sales.[Order]
  WHERE EmployeeId = @empid
)
SELECT orderyear, COUNT(DISTINCT CustomerId) AS numcusts
FROM C
GROUP BY orderyear;
GO

---------------------------------------------------------------------
-- Defining Multiple CTEs
---------------------------------------------------------------------

WITH C1 AS
(
  SELECT YEAR(orderdate) AS orderyear, CustomerId
  FROM Sales.[Order]
),
C2 AS
(
  SELECT orderyear, COUNT(DISTINCT CustomerId) AS numcusts
  FROM C1
  GROUP BY orderyear
)
SELECT orderyear, numcusts
FROM C2
WHERE numcusts > 70;

---------------------------------------------------------------------
-- Multiple References
---------------------------------------------------------------------

WITH YearlyCount AS
(
  SELECT YEAR(orderdate) AS orderyear,
    COUNT(DISTINCT CustomerId) AS numcusts
  FROM Sales.[Order]
  GROUP BY YEAR(orderdate)
)
SELECT Cur.orderyear, 
  Cur.numcusts AS curnumcusts, Prv.numcusts AS prvnumcusts,
  Cur.numcusts - Prv.numcusts AS growth
FROM YearlyCount AS Cur
  LEFT OUTER JOIN YearlyCount AS Prv
    ON Cur.orderyear = Prv.orderyear + 1;

---------------------------------------------------------------------
-- Recursive CTEs (Optional, Advanced)
---------------------------------------------------------------------

WITH EmpsCTE AS
(
  SELECT EmployeeId, EmployeeManagerId, EmployeeFirstName, EmployeeLastName
  FROM HumanResources.Employee
  WHERE EmployeeId = 2
  
  UNION ALL
  
  SELECT C.EmployeeId, C.EmployeeManagerId, C.EmployeeFirstName, C.EmployeeLastName
  FROM EmpsCTE AS P
    INNER JOIN HumanResources.Employee AS C
      ON C.EmployeeManagerId = P.EmployeeId
)
SELECT EmployeeId, EmployeeManagerId, EmployeeFirstName, EmployeeLastName
FROM EmpsCTE;

---------------------------------------------------------------------
-- Views
---------------------------------------------------------------------

---------------------------------------------------------------------
-- Views Described
---------------------------------------------------------------------

-- Creating USACusts View
DROP VIEW IF EXISTS Sales.USACusts;
GO
CREATE VIEW Sales.USACusts
AS 

SELECT
  CustomerId, CustomerCompanyName, CustomerAddress,
  CustomerCity, CustomerRegion, CustomerPostalCode, CustomerCountry
FROM Sales.Customer
WHERE CustomerCountry = N'USA';
GO

SELECT CustomerId, ShipToName
FROM Sales.[Order];
GO

---------------------------------------------------------------------
-- Views and ORDER BY
---------------------------------------------------------------------

-- ORDER BY in a View is not Allowed
/*
ALTER VIEW Sales.USACusts
AS

SELECT
  custid, companyname, contactname, contacttitle, address,
  city, region, postalcode, country, phone, fax
FROM Sales.Customers
WHERE country = N'USA'
ORDER BY region;
GO
*/

-- Instead, use ORDER BY in Outer Query
SELECT CustomerId, ShipToName, ShipToRegion
FROM Sales.[Order]
ORDER BY ShipToRegion;
GO

-- Do not Rely on TOP 
ALTER VIEW Sales.USACusts
AS

SELECT
  CustomerId, CustomerCompanyName, CustomerAddress,
  CustomerCity, CustomerRegion, CustomerPostalCode, CustomerCountry
FROM Sales.Customer
WHERE CustomerCountry = N'USA';
GO

-- Query USACusts
SELECT CustomerId, ShipToName, ShipToRegion
FROM Sales.[Order];
GO

-- DO NOT rely on OFFSET-FETCH, even if for now the engine does return rows in rder
ALTER VIEW Sales.USACusts
AS

SELECT
  CustomerId, CustomerCompanyName, CustomerAddress,
  CustomerCity, CustomerRegion, CustomerPostalCode, CustomerCountry
FROM Sales.Customer
WHERE CustomerCountry = N'USA';
GO

--OFFSET 0 ROWS;
--GO

-- Query USACusts
SELECT CustomerId, CustomerCompanyName, CustomerRegion
FROM Sales.USACusts;
GO

---------------------------------------------------------------------
-- View Options
---------------------------------------------------------------------

---------------------------------------------------------------------
-- ENCRYPTION
---------------------------------------------------------------------

ALTER VIEW Sales.USACusts
AS

SELECT
  CustomerId, CustomerCompanyName, CustomerAddress,
  CustomerCity, CustomerRegion, CustomerPostalCode, CustomerCountry
FROM Sales.Customer
WHERE CustomerCountry = N'USA';
GO

GO

SELECT OBJECT_DEFINITION(OBJECT_ID('Sales.USACusts'));
GO

ALTER VIEW Sales.USACusts WITH ENCRYPTION
AS

SELECT
  CustomerId, CustomerCompanyName, CustomerAddress,
  CustomerCity, CustomerRegion, CustomerPostalCode, CustomerCountry
FROM Sales.Customer
WHERE CustomerCountry = N'USA';
GO

SELECT OBJECT_DEFINITION(OBJECT_ID('Sales.USACusts'));

EXEC sp_helptext 'Sales.USACusts';
GO

---------------------------------------------------------------------
-- SCHEMABINDING
---------------------------------------------------------------------

ALTER VIEW Sales.USACusts WITH SCHEMABINDING
AS

SELECT
  CustomerId, CustomerCompanyName, CustomerAddress,
  CustomerCity, CustomerRegion, CustomerPostalCode, CustomerCountry
FROM Sales.Customer
WHERE CustomerCountry = N'USA';
GO

-- Try a schema change
/*
ALTER TABLE Sales.Customers DROP COLUMN address;
*/
GO

---------------------------------------------------------------------
-- CHECK OPTION
---------------------------------------------------------------------

-- Notice that you can insert a row through the view
INSERT INTO Sales.USACusts(
  CustomerCompanyName, CustomerAddress,
  CustomerCity, CustomerRegion, CustomerPostalCode, CustomerCountry)
 VALUES(
  N'Customer ABCDE', N'Address ABCDE',
  N'London', NULL, N'12345', N'UK');

-- But when you query the view, you won't see it
SELECT CustomerId, CustomerCompanyName, CustomerCountry
FROM Sales.USACusts
WHERE CustomerCompanyName = N'Customer ABCDE';

-- You can see it in the table, though
SELECT CustomerId, CustomerCompanyName, CustomerCountry
FROM Sales.USACusts
WHERE CustomerCompanyName = N'Customer ABCDE';

GO

-- Add CHECK OPTION to the View
ALTER VIEW Sales.USACusts WITH SCHEMABINDING
AS

SELECT
  CustomerCompanyName, CustomerAddress,
  CustomerCity, CustomerRegion, CustomerPostalCode, CustomerCountry
FROM Sales.Customer
WHERE CustomerCountry = N'USA'
WITH CHECK OPTION;
GO

-- Notice that you can't insert a row through the view
/*
INSERT INTO Sales.USACusts(
  companyname, contactname, contacttitle, address,
  city, region, postalcode, country, phone, fax)
 VALUES(
  N'Customer FGHIJ', N'Contact FGHIJ', N'Title FGHIJ', N'Address FGHIJ',
  N'London', NULL, N'12345', N'UK', N'012-3456789', N'012-3456789');
*/
GO

-- Cleanup
DELETE FROM Sales.Customer
WHERE CustomerId > 91;

DROP VIEW IF EXISTS Sales.USACusts;
GO

---------------------------------------------------------------------
-- Inline User Defined Functions
---------------------------------------------------------------------

-- Creating GetCustOrders function
--USE TSQLV4;
DROP FUNCTION IF EXISTS dbo.GetCustOrders;
GO
CREATE FUNCTION dbo.GetCustOrders
  (@cid AS INT) RETURNS TABLE
AS
RETURN
  SELECT orderid, CustomerId, EmployeeId, orderdate, requireddate,
    ShipToDate, ShipperId, freight, ShipToName, ShipToAddress, ShipToCity,
    ShipToRegion, ShipToPostalCode, ShipToCountry
  FROM Sales.[Order]
  WHERE CustomerId = @cid;
GO

-- Test Function
SELECT orderid, CustomerId
FROM dbo.GetCustOrders(1) AS O;

SELECT O.orderid, O.CustomerId, OD.productid, OD.qty
FROM dbo.GetCustOrders(1) AS O
  INNER JOIN Sales.OrderDetail AS OD
    ON O.orderid = OD.orderid;
GO

-- Cleanup
DROP FUNCTION IF EXISTS dbo.GetCustOrders;
GO

---------------------------------------------------------------------
-- APPLY
---------------------------------------------------------------------

SELECT S.shipperid, E.EmployeeId
FROM Sales.Shipper AS S
  CROSS JOIN HumanResources.Employee AS E;

SELECT S.shipperid, E.EmployeeId
FROM Sales.Shipper AS S
  CROSS APPLY HumanResources.Employee AS E;

-- 3 most recent orders for each customer
SELECT C.CustomerId, A.OrderId, A.orderdate
FROM Sales.Customer AS C
  CROSS APPLY
    (SELECT TOP (3) orderid, EmployeeId, orderdate, requireddate 
     FROM Sales.[Order] AS O
     WHERE O.CustomerId = C.CustomerId
     ORDER BY orderdate DESC, orderid DESC) AS A;

-- With OFFSET-FETCH
SELECT C.CustomerId, A.orderid, A.orderdate
FROM Sales.Customer AS C
  CROSS APPLY
    (SELECT orderid, EmployeeId, orderdate, requireddate 
     FROM Sales.[Order] AS O
     WHERE O.CustomerId = C.CustomerId
     ORDER BY orderdate DESC, orderid DESC
     OFFSET 0 ROWS FETCH NEXT 3 ROWS ONLY) AS A;

-- 3 most recent orders for each customer, preserve customers
SELECT C.CustomerId, A.orderid, A.orderdate
FROM Sales.Customer AS C
  OUTER APPLY
    (SELECT TOP (3) orderid, EmployeeId, orderdate, requireddate 
     FROM Sales.[Order] AS O
     WHERE O.CustomerId = C.CustomerId
     ORDER BY orderdate DESC, orderid DESC) AS A;

-- Creation Script for the Function TopOrders
DROP FUNCTION IF EXISTS dbo.TopOrders;
GO
CREATE FUNCTION dbo.TopOrders
  (@custid AS INT, @n AS INT)
  RETURNS TABLE
AS
RETURN
  SELECT TOP (@n) orderid, EmployeeId, orderdate, requireddate 
  FROM Sales.[Order]
  WHERE CustomerId = @custid
  ORDER BY orderdate DESC, orderid DESC;
GO

SELECT
  C.CustomerId, C.CustomerCompanyName,
  A.orderid, A.EmployeeId, A.orderdate, A.requireddate 
FROM Sales.Customer AS C
  CROSS APPLY dbo.TopOrders(C.CustomerId, 3) AS A;
