---------------------------------------------------------------------
-- INNER Joins
---------------------------------------------------------------------
-- Inner join keyword allows us to select records that have matching values
-- in both tables
-- Here the values of the column empid between tables HR.Employees & Sales.[Order] 
-- under the aliases E and O, are compared and joined if they match

USE Northwinds2020TSQLV6;

-- SQL-92
SELECT E.EmployeeId--E.firstname, E.lastname, O.orderid
FROM HumanResources.Employee AS E
  INNER JOIN Sales.[Order] AS O
    ON E.EmployeeId = O.EmployeeId;

SELECT E.EmployeeId, E.EmployeeFirstName, E.EmployeeLastName, O.orderid
FROM HumanResources.Employee AS E, Sales.[Order] AS O;
GO

-- Audit table for updates against OrderDetails
USE Northwinds2020TSQLV6;

DROP TABLE IF EXISTS Sales.OrderDetailsAudit;

CREATE TABLE Sales.OrderDetailsAudit
(
  lsn        INT NOT NULL IDENTITY,
  orderid    INT NOT NULL,
  productid  INT NOT NULL,
  dt         DATETIME NOT NULL,
  loginname  sysname NOT NULL,
  columnname sysname NOT NULL,
  oldval     SQL_VARIANT,
  newval     SQL_VARIANT,
  CONSTRAINT PK_OrderDetailsAudit PRIMARY KEY(lsn),
  CONSTRAINT FK_OrderDetailsAudit_OrderDetails
    FOREIGN KEY(orderid, productid)
    REFERENCES Sales.OrderDetail(orderid, productid)
);

SELECT OD.orderid, OD.productid, --OD.lsn,
  ODA.dt, ODA.loginname, ODA.oldval, ODA.newval
FROM Sales.OrderDetail AS OD
  INNER JOIN Sales.OrderDetailsAudit AS ODA
    ON OD.orderid = ODA.orderid
    AND OD.productid = ODA.productid
WHERE ODA.columnname = N'qty';

-- Unique pairs of employees
SELECT
  E1.EmployeeId, E1.EmployeeFirstName, E1.EmployeeLastName,
  E2.EmployeeId, E2.EmployeeFirstName, E2.EmployeeLastName
FROM HumanResources.Employee AS E1
  INNER JOIN HumanResources.Employee AS E2
    ON E1.EmployeeId < E2.EmployeeId;

---------------------------------------------------------------------
-- Multi-Join Queries
---------------------------------------------------------------------
-- SQL multi join is a query that contains the same or different join type,
-- used more than once
SELECT
  C.EmployeeId, C.Freight, O.orderid,
  OD.productid, OD.orderid
FROM Sales.[Order] AS C
  INNER JOIN Sales.[Order] AS O
    ON C.EmployeeId = O.EmployeeId
  INNER JOIN Sales.OrderDetailsAudit AS OD
    ON O.orderid = OD.orderid;

-- Customers and their orders, including customers with no orders
SELECT C.CustomerId, C.CustomerCompanyName, O.orderid
FROM Sales.Customer AS C
  LEFT OUTER JOIN Sales.[Order] AS O
    ON C.CustomerId = O.CustomerId;

-- Customers with no orders
SELECT C.CustomerId, C.CustomerCompanyName
FROM Sales.Customer AS C
  LEFT OUTER JOIN Sales.[Order] AS O
    ON C.CustomerId = O.CustomerId
WHERE O.orderid IS NULL;

---------------------------------------------------------------------
-- Including Missing Values
---------------------------------------------------------------------

SELECT DATEADD(day, n-1, CAST('20140101' AS DATE)) AS orderdate
FROM dbo.Nums
WHERE n <= DATEDIFF(day, '20140101', '20161231') + 1
ORDER BY orderdate;

SELECT DATEADD(day, Nums.n - 1, CAST('20140101' AS DATE)) AS orderdate,
  O.orderid, O.CustomerId, O.EmployeeId
FROM dbo.Nums
  LEFT OUTER JOIN Sales.[Order] AS O
    ON DATEADD(day, Nums.n - 1, CAST('20140101' AS DATE)) = O.orderdate
WHERE Nums.n <= DATEDIFF(day, '20140101', '20161231') + 1
ORDER BY orderdate;

SELECT C.CustomerId, C.CustomerCompanyName, O.CustomerId, O.orderdate
FROM Sales.Customer AS C
  LEFT OUTER JOIN Sales.[Order] AS O
    ON C.CustomerId = O.CustomerId
WHERE O.orderdate >= '20160101';

---------------------------------------------------------------------
-- Using Outer Joins in a Multi-Join Query
---------------------------------------------------------------------

SELECT C.CustomerId, O.orderid, OD.OrderId, OD.OrderDate
FROM Sales.Customer AS C
  LEFT OUTER JOIN Sales.[Order] AS O
    ON C.CustomerId = O.CustomerId
  INNER JOIN Sales.[Order] AS OD
    ON O.orderid = OD.orderid;

SELECT C.CustomerId, O.orderid, OD.OrderId, OD.OrderDate
FROM Sales.Customer AS C
  LEFT OUTER JOIN Sales.[Order] AS O
    ON C.CustomerId = O.CustomerId
  INNER JOIN Sales.[Order] AS OD
    ON O.orderid = OD.orderid;

-- Option 1: use outer join all along
SELECT C.CustomerId, O.orderid, OD.OrderId, OD.OrderDate
FROM Sales.Customer AS C
  LEFT OUTER JOIN Sales.[Order] AS O
    ON C.CustomerId = O.CustomerId
  LEFT OUTER JOIN Sales.[Order] AS OD
    ON O.orderid = OD.orderid;

-- Option 2: change join order
SELECT C.CustomerId, O.orderid, OD.OrderId, OD.OrderId
FROM Sales.[Order] AS O
  INNER JOIN Sales.[Order] AS OD
    ON O.orderid = OD.orderid
  RIGHT OUTER JOIN Sales.Customer AS C
     ON O.CustomerId = C.CustomerId;

-- Option 3: use parentheses
SELECT C.CustomerId, O.orderid, OD.OrderId, OD.OrderId
FROM Sales.Customer AS C
  LEFT OUTER JOIN
      (Sales.[Order] AS O
         INNER JOIN Sales.[Order] AS OD
           ON O.orderid = OD.orderid)
    ON C.CustomerId = O.CustomerId;

---------------------------------------------------------------------
-- Using the COUNT Aggregate with Outer Joins
---------------------------------------------------------------------

SELECT C.CustomerId, COUNT(*) AS numorders
FROM Sales.Customer AS C
  LEFT OUTER JOIN Sales.[Order] AS O
    ON C.CustomerId = O.CustomerId
GROUP BY C.CustomerId;

SELECT C.CustomerId, COUNT(O.orderid) AS numorders
FROM Sales.Customer AS C
  LEFT OUTER JOIN Sales.[Order] AS O
    ON C.CustomerId = O.CustomerId
GROUP BY C.CustomerId;